# Taven — specifikace stránek

Jedna MD na obrazovku. Zdroj: `Taven.dc.html` (21 obrazovek). Systémová pravidla jsou v `../DESIGN.md` a neopakují se tady — tyto soubory popisují obsah, stavy a chování konkrétní stránky.

## Veřejné
- [01 — Landing](01-landing.md)
- [02 — Jak to funguje](02-jak-to-funguje.md)
- [03 — Ceník](03-cenik.md)
- [04 — Ukázky](04-ukazky.md)
- [05 — Detail ukázky](05-ukazka-detail.md)
- [06 — Potřebuji model](06-potrebuji-model.md)
- [07 — Kontakt](07-kontakt.md)

## Tok objednávky
- [08 — Konfigurátor](08-konfigurator.md)
- [09 — Checkout](09-checkout.md)
- [10 — Přijato](10-prijato.md)
- [11 — Sledování zakázky](11-sledovani.md)

## Účet
- [12 — Přihlášení](12-prihlaseni.md)
- [13 — Aktivace účtu](13-aktivace.md)
- [14 — Moje zakázky](14-moje-zakazky.md)
- [15 — Nastavení](15-nastaveni.md)

## Právní a podpora
- [16 — VOP](16-vop.md)
- [17 — Reklamace](17-reklamace.md)
- [18 — Ochrana soukromí](18-soukromi.md)

## Systémové listy
- [19 — Responzivně](19-responzivne.md)
- [20 — Logo](20-logo.md)
- [21 — Tokeny a komponenty](21-tokeny.md)

## Šablony stránek

| Rodina | Hlavička | Patička | Stránky |
| --- | --- | --- | --- |
| Veřejná / obsahová | `BrandHeader` + `HomepageNavigation` | `TitleBlockFooter` | 01–07 |
| Aplikační tok | `ProcessHeader` + `OrderIndicator` | `CompactTitleBlockFooter` | 08–11 |
| Účet | zjednodušená účtová hlavička | `CompactTitleBlockFooter` | 12–15 |
| Právní dokument | `BrandHeader` + navigace | `TitleBlockFooter` | 16–18 |
