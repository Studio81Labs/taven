# 06 — Potřebuji model

`screen: 'model'` · `LIST 04 / 05` · veřejná šablona

## Účel
Druhá cílovka pro zákazníky bez souboru. Musí být **jasně odlišená** od automatického tisku.

## Struktura
1. **Hero** — `LIST 04 / POTŘEBUJI MODEL` + **Nemáš model? Pošli fotku nebo náčrt.** Vpravo odstavec o ručním posouzení a odkazová linka `BEZ ZÁVAZNÉ CENY DO DVOU MINUT / nabídka do 24 hodin, e-mailem`.
2. **Co zvládneme** — pět případů: prasklý plastový díl · jednoduchý náhradní díl · držák, konzole, podložka · díl podle rozměrů · úprava existujícího modelu. Doprovodná věta přiznává limity.
3. **Proces** — pět spojených cel: `01 PODKLADY` → `02 POSOUZENÍ` → `03 NABÍDKA` → `04 MODEL` → `05 TISK`. První cela bílá s modrou spodní linkou.
4. **Formulář** — bílý dokument, `FORMULÁŘ / 06 POLÍ`:
   - `01` Co to je a k čemu to slouží (textarea)
   - `02` Fotky a podklady (dropzone, JPG · PNG · PDF · STL, max. 10)
   - `03` Klíčové rozměry
   - `04` Počet kusů (mono)
   - `05` Musí to někam pasovat?
   - `06` E-mail (mono)
   - `Odeslat poptávku` + *Na modelování se ozveme s individuální nabídkou. Nic neplatíš, dokud ji nepotvrdíš.*

## Pravidla
Nikdy neslibovat, že z fotky vznikne cokoli. Nikde neuvádět závaznou cenu ani „do dvou minut“. Složité skořepiny a přesné závity odmítnout rovnou.
