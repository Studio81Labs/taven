# 07 — Kontakt

`screen: 'kontakt'` · `LIST 05 / 05` · veřejná šablona

## Účel
Malá stránka. Rozděluje tři typy dotazů a uvádí právní identifikaci — bez výrobní adresy.

## Struktura
`KONTAKT / TAVEN` + **Napiš nám**.

**Levý blok (7fr)** — rozpis se třemi celami a spodní lištou:

| Tag | Nadpis | K čemu | E-mail |
| --- | --- | --- | --- |
| DOTAZ K ZAKÁZCE | Běžící zakázka | změna, termín, výdejní místo; uveď `TV-XXXX` | zakazky@taven.cz |
| OBECNÝ DOTAZ | Před objednáním | materiál, možnosti, jestli to vytiskneme | info@taven.cz |
| MODELÁŘSKÁ POPTÁVKA | Nemáš model | fotky a rozměry, nebo formulář | model@taven.cz |

Spodní lišta: `ODPOVÍDÁME DO 24 HODIN V PRACOVNÍ DNY` · `U DOTAZU K ZAKÁZCE UVEĎ ČÍSLO TV-XXXX`.

**Pravý blok (4fr)** — `PROVOZOVATEL`: společnost, IČO, sídlo, telefon, e-mail, lhůta odpovědi. Pod tím: *Výrobní adresu nezveřejňujeme.*

## Nepoužívat
Mapa, stock foto dílny, kontaktní formulář duplikující e-maily, výrobní adresa.
