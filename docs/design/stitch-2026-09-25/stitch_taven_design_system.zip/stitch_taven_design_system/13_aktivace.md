# 13 — Aktivace účtu

`screen: 'aktivace'` · účtová šablona

## Účel
Nepovinná nabídka **po zaplacení**. Zakázka je přijatá tak či tak.

## Struktura
**Levý sloupec** — `NEPOVINNÉ / PO ZAKÁZCE TV-2604` (modře) + **Založit účet** + odstavec. Pod tím čtyři přínosy: zakázky a doklady na jednom místě · objednat znovu se stejnou konfigurací · reklamace bez hledání čísla · rozpracované objednávky se neztratí.

Uzavírá důležitá poznámka: *Účet neznamená, že si necháváme tvoje modely natrvalo — výrobní soubory mažeme po 90 dnech stejně jako u hostů.*

**Pravý sloupec** — `E-MAIL ZE ZAKÁZKY` předplněný a neaktivní, `JMÉNO — NEPOVINNÉ`, `Aktivovat účet` (primární), `Pokračovat bez účtu` (sekundární).

## Pravidla
Nikdy neimplikovat trvalé uchování nahraných výrobních souborů. Odmítnutí musí být stejně snadné jako přijetí.
