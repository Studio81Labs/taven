# 14 — Moje zakázky

`screen: 'account'` · účtová hlavička + `CompactTitleBlockFooter`

## Účel
Archiv zakázek jako **registr výkresů**, ne dashboard. Číslo zakázky je identifikátor jobu.

## Struktura
Hlavička: `TAVEN.` + e-mail + `ODHLÁSIT`.

Záhlaví listu: `ZÁKAZNICKÝ ARCHIV / 03 ZAKÁZKY` + **Moje zakázky**; vpravo `REGISTR ZAKÁZEK / LIST 01 / 01 · datum` a `NAHRÁT MODEL`.

Kótový předěl `ZÁZNAM / ZAKÁZKA / STAV / ČÁSTKA`.

Každý záznam `74px / 1fr / auto`:
- **ZÁZNAM** `01`
- číslo zakázky velkým mono, `REV. 01`, stav (`VÝROBA` modře u živé, `DORUČENO` neutrálně)
- pětisegmentový pruh fáze: hotové `--ink`, aktuální `--accent`, budoucí `--rule`
- podřádek: `ČEKÁ NA ODSOUHLASENÍ FOTKY` / `VYZVEDNUTO 18. 7. 2026`
- **akce u záznamu**, ne v globálním toolbaru: `OTEVŘÍT ZAKÁZKU`, `ODSOUHLASIT FOTKU`, `OBJEDNAT ZNOVU`, `STÁHNOUT DOKLAD`, `REKLAMACE`
- vpravo `DATUM / POLOŽKY / ČÁSTKA`

Uzavírá: *Archiv je jen pohodlí. Sledování i odsouhlasení fotky funguje stejně bez přihlášení, přes odkaz z e-mailu.*

## Pravidla
Částka živé zakázky se odvozuje ze stejného zdroje jako checkout a sledování — nikdy hardcoded literál. `OBJEDNAT ZNOVU` je pro Taven klíčová akce. Žádné avatary, notifikační centrum, personalizace ani widgety.
