# 18 — Ochrana soukromí

`screen: 'soukromi'` · `DOKUMENT GD-01` · `LIST 01 / 01` · veřejná šablona

## Účel
Maximálně transparentní technický přehled nakládání s daty a modely. Zákazník musí ihned vědět, co se děje s jeho výrobními soubory.

## Struktura
Nadpis `DOKUMENT GD-01 / REVIZE 01` + **Ochrana soukromí a nakládání s daty**.

**Metadatový rozpis** (5 cel): `DOKUMENT` · `REVIZE` · `ÚČINNOST` · `SPRÁVCE` · `RETENCE SOUBORŮ 90 DNÍ`.

**Klíčové sdělení (Hero block)**:
*Výrobní soubory (STL, 3MF, STEP) mažeme z úložiště automaticky po 90 dnech od expedice zakázky — u hostů i registrovaných zákazníků stejně.*

**Tabulka retence a zpracování dat**:
| Typ údaje | Účel | Doba uchování | Zabezpečení |
| --- | --- | --- | --- |
| Výrobní modely (STL, 3MF, STEP) | Příprava tisku, slicing, výroba | 90 dní od expedice, poté skartace | Šifrované S3 úložiště, neveřejné |
| Parametry zakázky (G-code metadata) | Archivace nastavení a dotisk | 1 rok pro opakované objednání | Oddělená databáze |
| Fotodokumentace dílu (QC foto) | Odsouhlasení a řešení reklamací | 6 měsíců | Privátní přístup přes token |
| E-mail a telefon | Doručení, notifikace, stav zakázky | Po dobu plnění smlouvy a záruky | Šifrovaný přenos |
| Fakturační údaje a doklady | Zákonná povinnost účetnictví | 10 let (dle zákona o účetnictví) | Zabezpečený archiv |

**Oddíly textu (max-width: 660px)**:
1. **Správce údajů** — identifikace Studio81 Labs, kontakt pověřence `dpo@taven.cz`.
2. **Výrobní data a duševní vlastnictví** — Taven neuplatňuje žádná práva k nahraným modelům, neposkytuje modely třetím stranám ani je nepoužívá pro trénování AI.
3. **Předávání dopravcům** — předáváme pouze jméno, telefon a e-mail pro doručení zásilky (Zásilkovna, Balíkovna).
4. **Práva zákazníka** — právo na výmaz, přístup, opravu a export dat. Jednoduché uplatnění e-mailem bez formulářových bariér.

## Pravidla
Žádný nesrozumitelný právnický žargon. Technicky přesné lhůty a přímá garance skartace modelů.
