# 19 — Responzivně

`screen: 'responzivne'` · systémový přehled adaptace rozhraní

## Účel
Technický přehled a pravidla adaptace rozhraní Taven pro tři zlomové šířky: Desktop (1440px), Tablet (768px) a Mobil (390px).

## Principy adaptace
- **Technická identita přetrvává**: Na mobilu se identita technického výkresu nese typografií (IBM Plex Sans / Mono), přesnými linkami 1px a metadaty — ne rastrem (rastr se na displeji mobilu vypíná, aby nerušil čitelnost).
- **Závazná cena stále na očích**: Na mobilu je závazná cena ukotvena ve sticky spodní liště spolu s primárním CTA tlačítkem.
- **Nulový border-radius**: Zachován napříč všemi zařízeními (`0px`).
- **Touch targets**: Minimální klikací plocha `44px`, u hlavních tlačítek `48px`.

## Zlomové formáty

| Formát | Šířka | Rozložení konfigurátoru | Navigace | Patička |
| --- | --- | --- | --- | --- |
| **Desktop** | `1440px` | 2 sloupce `7fr / 5fr`, fixní dělicí linka, stabilní geometrie | Plná lišta `01 JAK TO FUNGUJE` ... `04 POTŘEBUJI MODEL` + `NAHRÁT MODEL` | Plný rozpis `TitleBlockFooter` (4 cely + spodní lišta) |
| **Tablet** | `768px` | 1 sloupec — plátno modelu nahoře, ovládací panel dole | Kompaktní indexovaná navigace | Dvouřádkový rozpis cel |
| **Mobil** | `390px` | 1 sloupec, plátno modelu 260px, sticky spodní pruh s cenou | `TAVEN.` + stav kroku `02/05` + menu tlačítko | Zjednodušený kompaktní rozpis (žádný vertikální nekonečný stack) |

## Pravidla
Nikdy neschovávat klíčová metadata. Závazná cena nesmí zapadnout pod záhyb obrazovky.
