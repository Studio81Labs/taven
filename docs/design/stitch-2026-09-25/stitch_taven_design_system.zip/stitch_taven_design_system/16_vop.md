# 16 — VOP

`screen: 'vop'` · `DOKUMENT VOP / REVIZE 01` · `LIST 01 / 08`

## Účel
Řízený technický dokument. Čitelnost je důležitější než výtvarnost.

## Struktura
Nadpis `DOKUMENT VOP / REVIZE 01` + **Všeobecné obchodní podmínky**.

**Metadatový rozpis** (5 cel): `DOKUMENT` · `REVIZE` · `ÚČINNOST` · `PROVOZOVATEL` · `LIST`.

**Obsah** (3fr, sticky) — osm číslovaných odkazů.
**Text** (8fr) — číslované oddíly, `max-width: 660px`:

`01` Úvodní ustanovení · `02` Objednávka a cena · `03` Podklady zákazníka · `04` Výroba · `05` Dodání · `06` Odpovědnost · `07` Reklamace · `08` Platby a refundace

## Klíčová tvrzení
- Cena je závazná a platí 48 hodin; vzniká ze slicingu, ne z hmotnosti.
- Minimální cena tisku 250 Kč, malá zakázka +50 Kč do 100 g, expres 2× cena tisku. Po zaplacení se cena nemění.
- Zákazník odpovídá za práva k modelu; Taven může zakázku odmítnout.
- Bez odsouhlasení fotky se zakázka neodesílá.
- Taven odpovídá za soulad se schváleným modelem a konfigurací, **ne** za funkční vhodnost.
- Provozovatel není plátcem DPH.

## Pravidla
Nezveřejněné právní hodnoty zůstávají jako `[DOPLNIT PO PRÁVNÍ KONTROLE]`, `[DATUM]`, `[IČO]`. Za dlouhým textem **nikdy rastr**. Právní text nikdy v mono ani verzálkách.
