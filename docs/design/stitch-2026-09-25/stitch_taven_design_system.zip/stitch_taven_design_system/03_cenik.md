# 03 — Ceník

`screen: 'cenik'` · `LIST 02 / 05` · veřejná šablona

## Účel
Vysvětlit cenu průhledně, aniž bychom předstírali univerzální sazbu za gram.

## Struktura
1. **Hlavička listu** — `LIST 02 / CENÍK` + **Cena vzniká ze slicingu** + odstavec o tom, že rozhoduje čas stroje, ne hmotnost.
2. **Pravidla** — dva sloupce, každé pravidlo má název, vysvětlující větu a mono hodnotu:

| Pravidlo | Hodnota |
| --- | --- |
| Minimální cena tisku | 250 Kč |
| Malá zakázka (do 100 g) | +50 Kč |
| Doprava — výdejní místo | 79 Kč |
| Expresní výroba (do 24 h) | 2× cena tisku |
| Množstevní sleva | −8 % / −18 % |
| Materiály | PLA / PETG |

3. **Co s cenou hýbe** — sedm číslovaných veličin: dráhy trysky · materiál a spotřeba včetně podpěr · podpěry a jejich odstranění · čas tisku · výška vrstvy · počet kusů a sleva · rozvržení na podložky.
4. **Kótový předěl** `SKUTEČNÉ ZAKÁZKY / TŘI ZÁZNAMY` → tabulka záznamů:

| Č. | Díl | Gramáž | Materiál | Čas | Cena tisku |
| --- | --- | --- | --- | --- | --- |
| D-0142 | Kryt čerpadla | 42,8 g | PLA | 2 h 10 | 300 Kč |
| D-0139 | Držák senzoru, 12 ks | 233 g | PETG | 11 h 40 | 1 522 Kč |
| D-0128 | Šablona na vrtání | 118 g | PLA | 9 h 05 | 689 Kč |

5. **CTA** — `Spočítat cenu` + *Pro přesnou cenu nahraj model. Ceny jsou konečné, nejsme plátci DPH.*

## Nepoužívat
`od X Kč/g` jako hlavní sdělení. Placeholder `[X]` ve finálním konceptu. Cenové karty typu e-shop. Fake „doprava zdarma“.
