---
name: Taven Precision Blueprint
colors:
  surface: '#FFFFFF'
  surface-dim: '#dadad5'
  surface-bright: '#fafaf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4ef'
  surface-container: '#eeeee9'
  surface-container-high: '#e8e8e3'
  surface-container-highest: '#e3e3de'
  on-surface: '#1a1c19'
  on-surface-variant: '#444656'
  inverse-surface: '#2f312e'
  inverse-on-surface: '#f1f1ec'
  outline: '#747687'
  outline-variant: '#c4c5d9'
  surface-tint: '#2349ec'
  primary: '#002dbc'
  on-primary: '#ffffff'
  primary-container: '#1b44e8'
  on-primary-container: '#c8cfff'
  inverse-primary: '#bac3ff'
  secondary: '#5f5e59'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2db'
  on-secondary-container: '#65645f'
  tertiary: '#623900'
  on-tertiary: '#ffffff'
  tertiary-container: '#824e00'
  on-tertiary-container: '#ffc78c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bac3ff'
  on-primary-fixed: '#00115a'
  on-primary-fixed-variant: '#0030c6'
  secondary-fixed: '#e5e2db'
  secondary-fixed-dim: '#c9c6c0'
  on-secondary-fixed: '#1c1c18'
  on-secondary-fixed-variant: '#474742'
  tertiary-fixed: '#ffdcbb'
  tertiary-fixed-dim: '#ffb869'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#fafaf4'
  on-background: '#1a1c19'
  surface-variant: '#e3e3de'
  paper: '#EFEFEA'
  surface-2: '#F7F7F4'
  surface-preview: '#F7F7F3'
  field: '#FCFCFB'
  ink: '#1A1A16'
  ink-2: '#54554C'
  ink-3: '#66675F'
  rule: '#D9D9D2'
  rule-2: '#C9C9C1'
  accent: '#1B44E8'
  accent-hover: '#1236C4'
  accent-subtle: '#EEF2FF'
  accent-inverse: '#5C7CFF'
  warn: '#925B10'
  stop: '#B4441A'
  success: '#25705A'
  grid-minor: '#F1F1EC'
  grid-major: '#E4E4DE'
typography:
  hero:
    fontFamily: IBM Plex Sans
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 41px
    letterSpacing: -0.035em
  hero-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 37px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 29px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 29px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 25px
    letterSpacing: -0.01em
  body-base:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  legal:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 25px
    letterSpacing: 0em
  price-display:
    fontFamily: IBM Plex Mono
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  price-md:
    fontFamily: IBM Plex Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  label-mono:
    fontFamily: IBM Plex Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.12em
  meta-mono:
    fontFamily: IBM Plex Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.04em
  code-mono:
    fontFamily: IBM Plex Mono
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 17px
    letterSpacing: 0.02em
spacing:
  gutter: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
---

## Brand & Style

This design system translates the rigorous precision of an engineering blueprint into an uncompromising consumer fabrication service. The visual metaphor is an authentic technical drawing transformed into a high-speed digital interface: structured paper substrates, crisp drafting hairlines, and absolute typographic clarity. It explicitly rejects the design clichés of generic SaaS platforms, consumer e-commerce shopping carts, and impenetrable industrial CAD software.

The emotional signature is quiet engineering competence: deliberate, factual, and deterministically accurate. The interface communicates through verified slicing data, exact dimensions, bounding boxes, and binding commitments rather than marketing embellishments. The primary interaction rule is absolute discipline: 80% whitespace, technical paper canvas, and typography; 15% structural framing, leader lines, and drafting rules; and strictly less than 5% high-precision cobalt accent reserved exclusively for actionable decisions, confirmed selection states, and binding final prices.

## Colors

The chromatic architecture is strictly semantic: **Cobalt accent (`#1B44E8`) signifies a primary action, an active state, or a binding price. Deep ink (`#1A1A16`) signifies neither.**

- **Canvas & Drafting Planes:**
  - `paper` (`#EFEFEA`): Architectural drafting paper foundation providing tactile structure for application workflows.
  - `surface` (`#FFFFFF`): Bright white working plane used for 3D viewports, parameter configuration sheets, and formal documents.
  - `surface-2` (`#F7F7F4`): Secondary contextual plane for persistent workflow sidebars and metadata inspectors.
  - `surface-preview` (`#F7F7F3`): Calibrated viewport plane overlaid with engineering grids.
  - `field` (`#FCFCFB`): Dedicated, high-legibility input surface.

- **Ink Hierarchy:**
  - `ink` (`#1A1A16`): Heavy drafting ink for titles, outer blueprint frames, structural cross-sections, and primary text.
  - `ink-2` (`#54554C`): Mid-tier explanatory notes, step guidance, and secondary information.
  - `ink-3` (`#66675F`): Dense dimensional readings, technical metadata, and uppercase field labels.

- **Framing & Dividers:**
  - `rule` (`#D9D9D2`): Standard 1px drafting hairlines and table dividers.
  - `rule-2` (`#C9C9C1`): Heavy 2px boundaries for structural zone divisions and outer boundaries.

- **Semantic Actions & Signals:**
  - `accent` (`#1B44E8`): The single high-energy cobalt brand indicator. Limited to the period in the wordmark, the final binding price display, confirmed selections, and primary CTA triggers. Never used decoratively or across large surfaces.
  - `warn` (`#925B10`): Non-critical technical advisories, such as unit scaling ambiguities (mm vs. inch) or thin wall alerts.
  - `stop` (`#B4441A`): Hard file rejections, manifold mesh errors, and destructive actions.
  - `success` (`#25705A`): Preflight geometry validation and verified slicing confirmation.

## Typography

The typographic system is built on a two-tier structural rule: **IBM Plex Sans governs human language, prose, and body content; IBM Plex Mono governs every dimension, numerical quantity, price, timestamp, and metadata token without exception.**

Headlines remain bounded at a maximum of 38px desktop to ensure the layout never takes on the appearance of generic consumer marketing. Visual tension and hierarchy are established through the contrast between tight tabular mono data, sharp rules, and crisp text blocks.

All numerical elements must apply `font-variant-numeric: tabular-nums` to ensure exact vertical scanning across dimensional schedules, slice reports, and price breakdowns. Uppercase labels rendered in mono require a wide letter-spacing of `0.12em` to reflect the typography of CAD title blocks.

## Layout & Spacing

The layout is grounded in an asymmetrical, fixed-ratio engineering canvas capped at `1440px`. It enforces a non-shifting two-column split screen throughout the upload-to-checkout sequence:
- **Left Primary Workspace (`minmax(0, 1fr)`):** Set against a `#EFEFEA` paper substrate. Accommodates the interactive 3D model viewport, leader line overlays, XYZ bounding boxes, and geometry analysis reports.
- **Right Context Panel (`minmax(320px, 400px)`):** Set against a `#F7F7F4` or `#FFFFFF` structured card surface. Accommodates parameter options, unit pricing, real-time slicing progress, and primary CTA executions.

### Structural Spacing Rules
1. **Grid Increments:** Spacing distances map to an exact 4px architectural unit (`0.25rem`), scaling from micro gaps (`space-xs` = 4px) to section boundaries (`space-3xl` = 64px).
2. **Drafting Coordinate Zones:** The canvas may feature peripheral coordinate guides (`A–E`, `01–08`) printed within the outer gutters to mimic large-format drafting sheets.
3. **Dimension Separators:** Section dividers may incorporate centered inline dimension markers with bidirectional technical arrows. Limit usage strictly to 2–3 per view.
4. **Responsive Strategy:** Below 960px, the layout converts to a stacked single-column flow where the 3D model canvas sits directly above the configuration parameters. At 390px mobile, the navigation collapses into an indexed mono menu (`01–04 MENU`), with the binding price and primary CTA docked into a sticky zero-radius bottom bar.

## Elevation & Depth

This design system rejects drop shadows, ambient blurs, and glassmorphism. Elevation is communicated entirely through **structural borders, technical line weights, and layered drafting surfaces**:

1. **Border Weight as Depth:**
   - Base content partitions and card borders employ a crisp `1px solid #D9D9D2` hairline.
   - Primary viewport frames, outer canvas bounds, and title block modules use a firm `2px solid #1A1A16` structural outline.
2. **Tonal Planar Stacking:**
   - Baseline elevation (Z0) is the architectural paper plane (`#EFEFEA`).
   - Interactive document surfaces and 3D preview containers (Z1) sit on sharp, un-elevated `#FFFFFF` or `#F7F7F3` white planes.
   - Persistent utility panels and inspection drawers (Z2) use `#F7F7F4` with a bounding 1px border.
3. **Selected State Invariant:**
   - Active, focused, or confirmed selections (materials, stocked colors, infill density) never rely solely on color. They must use a combined visual treatment: a white `#FFFFFF` surface, a `1px solid #1B44E8` accent border, and an inset indicator `box-shadow: inset 2px 0 0 #1B44E8`.

## Shapes

The geometric rule for this system is absolute: **`0px` border-radius across all elements**.

No rounding is permitted on buttons, modal sheets, tooltips, tags, dropdown triggers, checkboxes, progress bars, or input fields. Corners remain strictly orthogonal (90 degrees), reinforcing the physical feel of sheared sheet metal, razor-cut architectural drafting paper, and precision CNC/3D-printed components.

## Components

### Buttons
- **Primary Action:** Solid `#1B44E8` background, `#FFFFFF` IBM Plex Sans 600 text, min-height 48px, zero radius, border `1px solid #1B44E8`. Hover transitions to `#1236C4`. Focus ring is `2px solid #1B44E8` with a 3px offset.
- **Secondary Action:** Unfilled `#FFFFFF` surface, `#1A1A16` IBM Plex Sans 600 text, framed in `1px solid #1A1A16`. On hover, the border and text become `#1B44E8`.
- **Destructive Action:** `#FFFFFF` background, `#B4441A` border and text.

### Parameter Selector Chips & Segmented Controls
- Rendered as contiguous horizontal or grid-aligned rectangular cells with `0px` radius.
- Standard state: `#FFFFFF` or `#FCFCFB` surface, framed in `1px solid #D9D9D2`, with IBM Plex Mono values.
- Selected state: `#FFFFFF` surface, `1px solid #1B44E8` border, and an inner accent marker `box-shadow: inset 2px 0 0 #1B44E8`.
- Stocked filament indicator: Shown via a 10px inline color square beside the material and color label. Never display options that are out of stock.

### Input Fields & Checkboxes
- **Text Inputs:** Height 44px (min), background `#FCFCFB`, border `1px solid #D9D9D2`, zero radius, IBM Plex Mono 13px value text. Focus is an un-blurred `outline: 2px solid #1B44E8` with 2px offset.
- **Labels:** Positioned strictly above the field in IBM Plex Mono, 10px uppercase, `letter-spacing: 0.12em`, color `#66675F`.
- **Checkboxes:** Sharp 18×18px squares, `0px` radius, `1px solid #1A1A16` perimeter, filling with `#1B44E8` when checked.

### Model Drawing Frame (3D Viewport)
- A dedicated `#F7F7F3` inspection canvas surrounded by a `1px solid #D9D9D2` border.
- Underlaid with an engineering drafting grid: 16px minor grid lines (`#F1F1EC`) and 80px major grid lines (`#E4E4DE`).
- Dynamic leader lines (`LeaderAnnotation`) connect model geometry directly to metadata pins (bounding volume, wall thickness, triangle count).

### Preflight Finding Cards
- Quiet diagnostic containers with a `#FFFFFF` surface and `1px solid #D9D9D2` border.
- Features a left status stripe (3px): `#25705A` for verified geometry, `#925B10` for scale confirmation, `#B4441A` for non-manifold errors.
- Text uses direct, conversational Czech, avoiding alarmist iconography.

### Title Block Footer (Engineering Title Block)
- Derived directly from standard technical drawing title blocks (ČSN/ISO).
- Structured inside a `2px solid #1A1A16` border on `#EFEFEA`, divided into distinct functional cells:
  1. *Brand & Mission:* Wordmark `TAVEN.` (`#1B44E8` period) with the service claim.
  2. *Legal Entity:* Operational data for Studio81 Labs, s.r.o. with registered address, company ID, and support channels.
  3. *Sheet & Revision:* Sheet index and revision identifier (`REV. launch-approvals-v0.1`).
  4. *Sub-Bar:* Direct links to Terms (VOP), Complaints, Privacy, and Contact.