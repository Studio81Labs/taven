# 19 — Responzivně

`screen: 'mobile'` · systémový list

## Účel
Ukázat, že identita přežije 390 px. Ne zmenšený desktop.

## Rámy na listu
Kótový předěl `ROZLOŽENÍ / 390 · 768 · 1440`, pak:

1. **Mobil 390 / Landing** — `TAVEN.` + `01–04 MENU`, hero na dva řádky, dropzone `Vyber soubor`, druhý vchod, technický výtah.
2. **Mobil 390 / Konfigurátor** — kontext kroku `02 KONFIGURACE / 05`, plátno modelu 190px s kótou, parametry pod sebou, **sticky cenová lišta** se závaznou cenou a CTA.
3. **Mobil 390 / Doprava a platba + patička** — výdejní místa 48px, `VÝROBNÍ LIST`, sticky cena, složený rozpis patičky (2 sloupce + spodní lišta).
4. **Mobil 390 / Objednávka o 3 položkách** — položky, rozpad, sticky cena, `Zaplatit` + `+ Přidat další model`.
5. **Mobil 390 / Moje zakázky** — záznamy se stavem, pruhem fáze a `REV.`
6. **Tablet 768 / Konfigurátor** — model **nad** ovládáním, parametry ve dvou sloupcích, cena a CTA v jednom pruhu dole.

## Pravidla
Navigace se skládá do `01–04 MENU` — indexy zůstávají. Kontext kroku nikdy nepřetéká. Závazná cena vždy u primární akce. Drawing zones a rastr se na mobilu zjednodušují; identitu nese typografie, linky, indexy a metadata. Cílové plochy 44px, tlačítka 48px. **Mobil je spotřebitelský checkout, ne miniaturní výkres.**
