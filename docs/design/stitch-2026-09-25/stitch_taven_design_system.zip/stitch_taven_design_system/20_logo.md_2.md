# 20 — Logo a značka

`screen: 'logo'` · specifikace logotypu a identity

## Účel
Definice ochranné značky Taven a práce s logotypem v technickém kontextu výkresu.

## Konstrukce značky
- **Primární logotyp**: `TAVEN.` — verzálky s pevnou tečkou na konci.
- **Typografie značky**: IBM Plex Sans Bold / SemiBold s mírně zúženým prostrkáním (`letter-spacing: -0.02em`).
- **Akcentní tečka**: Tečka za názvem je jediným nositelem modré barvy `--accent` (`#1B44E8`) v hlavičce. Zbývající písmena jsou v barvě `--ink` (`#1A1A16`).
- **Doprovodný claim**: `NAHRAJ. ZAPLAŤ. HOTOVO.` (verzálky, mono popisek).

## Tři směry značky

| Směr | Použití | Popis |
| --- | --- | --- |
| **01 Primární (Standard)** | Webová hlavička, doklady, štítky | `TAVEN.` s modrou tečkou + technická lokalizace `CZ / PRAHA` |
| **02 Kótovaný monogram** | Favicon, razítko na balíku, avatar | `[ T. ]` v kótovém ohraničení s rozměrem `24×24` |
| **03 Výrobní razítko** | Balicí páska, štítek na krabici | `TAVEN PROTOKOL / KONTROLA JAKOSTI` v technickém rámu 1px |

## Pravidla
Nikdy nepřidávat 3D efekty, stíny, gradienty ani ikony trysek nebo ozubených kol. Logo je technické typografické razítko.
