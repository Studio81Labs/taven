# 11 — Sledování zakázky

`screen: 'tracking'` · aplikační šablona · `05 VÝROBA` aktivní

## Účel
Jeden a tentýž dokument pro přihlášené i pro hosty s odkazem z e-mailu. Dvě verze sledování neexistují.

## Struktura
Pro přihlášené navíc drobenka `‹ MOJE ZAKÁZKY / TV-2604`.

**Levý sloupec (7fr)** — nadpis podle stavu (`Čeká na tvoje odsouhlasení` → `Balíme`) + podtitul se číslem zakázky.

`ProductionTimeline` — čas, stav, lidská věta:

| Čas | Stav | Věta |
| --- | --- | --- |
| 13:41 | Zaplaceno | Platba kartou přijata. Zakázka zařazena do fronty. |
| 13:44 | Ve frontě | Před tebou byla jedna zakázka. |
| 13:58 | Tiskne se | PLA grafitová, 0,20 mm. Odhad dokončení 15:20. |
| 14:02 | Kontrola a fotka | Díl vyjmut z podložky, podpěry odstraněny, rozměry přeměřeny. |
| — | Odesláno | Předáme dopravci po tvém odsouhlasení fotky. |

`QCPhotoCard` — `Fotka dílu k odsouhlasení` + `POŘÍZENO 14:02`, dvě fotky (`FOTO — SHORA`, `FOTO — DETAIL ZÁVITU`), akce `Souhlasím, odešlete` (primární) / `Něco nesedí` (sekundární) + *Bez odsouhlasení nic neodesíláme.*

Po odsouhlasení se karta mění na potvrzení `Odsouhlaseno v 14:09`.

**Pravý sloupec (5fr)** — `ZAKÁZKA / TV-2604`: položky, sleva, výdejní místo, `Zaplaceno`. Pod tím kontakt a lhůta odpovědi.

## Pravidla
**Nikdy neuvádět stroj ani obsluhu.** Zákazník neví a nemá vědět, kdo a na čem tiskne. Žádná interní terminologie stavového automatu.
