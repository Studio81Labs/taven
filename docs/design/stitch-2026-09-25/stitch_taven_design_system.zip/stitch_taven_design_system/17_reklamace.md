# 17 — Reklamace

`screen: 'reklamace'` · veřejná šablona · `LIST 01 / 01`

## Účel
Podpora, ne obranný právní text. Tón je vstřícný.

## Struktura
1. **Hero** — `REKLAMACE / PODPORA` + **Něco nesedí? Řešíme to.** + *Napiš nám dřív, než začneš díl opravovat. Většinu věcí vyřešíme dotiskem — a ten platíme my, pokud jsme se netrefili do modelu nebo konfigurace, kterou jsi schválil.*
2. **Otevření reklamace** (7fr) — `Máš číslo zakázky?` s předponou `TV-` a polem, vedle `Otevřít reklamaci`. Pod tím *Číslo najdeš v potvrzení objednávky. Přihlášení není potřeba.* Pro přihlášené navíc `NEBO VYBER Z ARCHIVU` se seznamem zakázek.
3. **Co pomůže** (4fr) — číslo zakázky · fotka dílu, ideálně s pravítkem · která položka to je · krátký popis.
4. **Čtyři situace** — čtyři cely s barevně odlišenými tagy:

| Tag | Situace | Řešení |
| --- | --- | --- |
| VÝROBNÍ VADA (modrá) | Vada tisku | dotisk na naše náklady |
| PODKLAD (`--warn`) | Problém v modelu | individuálně, často opravou modelu |
| PŘEPRAVA (`--warn`) | Poškození při přepravě | řešíme s dopravcem, nový kus |
| PASOVÁNÍ (`--ink-3`) | Nepasuje tam, kam mělo | úprava rozměru a dotisk |

5. **Uzavření** — *Taven ručí za to, že díl odpovídá modelu a konfiguraci, kterou jsi schválil. Neručíme za to, že se díl mechanicky hodí tam, kam ho chceš dát — na to je zkušební kus.* + odkaz na `VOP, oddíl 07`.

## Pravidla
Formální postup je odkazem, ne hlavním obsahem. Reklamace bez účtu musí fungovat.
