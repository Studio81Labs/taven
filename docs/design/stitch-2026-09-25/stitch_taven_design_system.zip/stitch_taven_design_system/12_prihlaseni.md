# 12 — Přihlášení

`screen: 'login'` · účtová šablona + `CompactTitleBlockFooter`

## Účel
Extrémně jednoduché. Účet je archiv zakázek, nic víc — a přihlášení to musí rovnou říct.

## Struktura
**Levý sloupec** — `PŘIHLÁŠENÍ / ARCHIV ZAKÁZEK` + **Přihlášení** + *Účet slouží hlavně jako archiv zakázek. K objednání, zaplacení, sledování ani odsouhlasení fotky ho nepotřebuješ — na to ti stačí odkaz z e-mailu.*

**Pravý sloupec** — dokument max. 420px: pole `E-MAIL` (mono) + `Poslat odkaz k přihlášení` + *Pošleme ti jednorázový odkaz. Žádné heslo si pamatovat nemusíš.*

Pod ním odkazová linka: *Účet nemáš? Není potřeba — nahraj model a objednej jako hosta.*

## Pravidla
Passwordless / magic link. Žádná registrační zeď, žádné sociální přihlášení, žádný SaaS portál.
