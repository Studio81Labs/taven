# 18 — Ochrana soukromí

`screen: 'soukromi'` · `DOKUMENT PRIVACY / REVIZE 01` · `LIST 01 / 07`

## Účel
Stejná dokumentová šablona jako VOP. Navíc vysvětluje retenci **výrobních souborů** — pro Taven neobvykle relevantní téma.

## Struktura
Metadatový rozpis: `DOKUMENT` · `REVIZE` · `ÚČINNOST` · `SPRÁVCE` · `LIST`.

Obsah (sticky) a číslované oddíly: `01` Správce a rozsah · `02` Jaké údaje zpracováváme · `03` Výrobní soubory · `04` Účel a právní základ · `05` Doba uložení · `06` Zpracovatelé · `07` Tvá práva.

**Tabulka retence** `DATA / ÚČEL / RETENCE`:

| Data | Účel | Retence |
| --- | --- | --- |
| Objednávka a doklady | plnění smlouvy, zákonná povinnost | `[DOPLNIT]` |
| STL / 3MF / STEP | výroba, dotisk, reklamace | **90 dní** |
| Fotografie z kontroly | doklad o provedení zakázky | `[DOPLNIT]` |
| Kontaktní údaje | komunikace k zakázce | `[DOPLNIT]` |
| Účet | archiv zakázek | do smazání účtu |

**Zvýrazněný blok** `DŮLEŽITÉ / VÝROBNÍ SOUBORY`: *Tvůj model potřebujeme jen k výrobě. Držíme ho 90 dní od odeslání zakázky — kdybys potřeboval dotisk nebo řešit reklamaci. Pak ho mažeme. Účet na tom nic nemění: soubory se v něm neschovávají natrvalo.*

## Pravidla
Zákonné lhůty se v mockupu nevymýšlejí — jen `[DOPLNIT]`. Devadesátidenní retence musí být srozumitelná běžnému zákazníkovi, ne jen právníkovi.
