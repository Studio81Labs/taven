# 02 — Jak to funguje

`screen: 'jak'` · `LIST 01 / 05` · veřejná šablona

## Účel
Celý postup bez toho, aby se stránka změnila v dokumentaci. Landing dává krátkou verzi, tady je úplná.

## Struktura
Hlavička listu: `LIST 01 / JAK TO FUNGUJE` + **Od souboru k hotovému dílu** + odstavec vpravo.

Sedm záznamů, každý ve třech sloupcích `120px / 1fr / 1fr`: index a tag · nadpis a text · odkazové poznámky.

| Krok | Tag | Nadpis | Poznámky |
| --- | --- | --- | --- |
| 01 | SOUBOR | Nahraješ model | STL · 3MF · STEP / sestava = výběr těles / víc modelů v jedné zakázce |
| 02 | KONTROLA | Zkontrolujeme, co jde vyrobit | NAČTENÍ SOUBORU / KONTROLA GEOMETRIE / SLICING A DRÁHY / VÝPOČET CENY |
| 03 | KONFIGURACE | Čtyři volby, nic víc | PLA / PETG · jen barvy na skladě · 0,28 / 0,20 / 0,12 mm |
| 04 | ZÁVAZNÁ CENA | Cena, která platí | minimální cena tisku 250 Kč / platí 48 hodin / žádné doúčtování |
| 05 | VÝROBA | Platba, fronta, tisk | fronta a odhad dokončení / materiál a výška vrstvy / stav v reálném čase |
| 06 | KONTROLA A FOTO | Nic neodejde bez souhlasu | přeměření / fotka celku i detailu / souhlas před expedicí |
| 07 | DORUČENÍ | Výdejní místo nebo pošta | Zásilkovna / Balíkovna / Z-Box · doprava 79 Kč · do 3 dnů |

Pak kótový předěl `ŘEZ A–A / JAK VZNIKÁ CENA` se stejným diagramem jako na landingu, a uzavření: **`Nahrát model`** + *Závaznou cenu uvidíš do dvou minut. Účet k tomu nepotřebuješ.*

## Pravidla
Krok 02 zobrazuje pipeline stejnými slovy jako panel `STAV SOUBORU` v konfigurátoru — zákazník musí poznat, že jde o totéž. Blokující stavy se vysvětlují jednou větou, ne technickou hodnotou.
