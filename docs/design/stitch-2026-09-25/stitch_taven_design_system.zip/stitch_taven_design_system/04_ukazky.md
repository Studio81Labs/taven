# 04 — Ukázky

`screen: 'ukazky'` · `LIST 03 / 05` · veřejná šablona

## Účel
Důvěra přes doklad o skutečné výrobě. Registr vyrobených dílů, ne galerie.

## Struktura
Hlavička listu `LIST 03 / UKÁZKY` + **Registr vyrobených dílů** + *Vlastní výtisky, neupravené fotky.*

Filtr: `VŠE / PLA / PETG / FUNKČNÍ DÍLY / PROTOTYPY` — vybraný stav modrý rám + inset linka. Vpravo počet: `06 ZÁZNAMŮ / VŠE`.

Mřížka 3 sloupce, `PartCard`: foto 4:3 s `FOTO` vlevo a číslem záznamu vpravo, pod ním název dílu (dominantní) a metadata `MATERIÁL / BARVA / MNOŽSTVÍ / KVALITA / REV.`

Záznamy: `D-0142` Kryt čerpadla · `D-0139` Držák senzoru · `D-0131` Náhradní kolečko · `D-0128` Šablona na vrtání · `D-0119` Model kliky · `D-0106` Průchodka kabelu.

## Chování
Karta otevírá [Detail ukázky](05-ukazka-detail.md). Filtr mění jen počet a obsah mřížky, ne geometrii.

## Pravidla
Fotografie je dominantní prvek, metadata sekundární. Filtrování se nepředělává — pět voleb je maximum. Fotky zveřejňujeme jen se souhlasem zákazníka.
