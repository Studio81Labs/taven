# 09 — Checkout

`screen: 'checkout'` · aplikační šablona · `03 DOPRAVA` aktivní

## Struktura
**Levý sloupec (7fr)**
1. `Kam to poslat` — pole města/PSČ + `Najít místo`, pod tím výdejní místa (Zásilkovna, Balíkovna, Z-Box) s adresou, vzdáleností a hodinami. Vybrané: modré kolečko + modrý rám.
2. `Kontakt` — jméno, e-mail, telefon.
3. `Platba` — Karta / Apple Pay / Bankovní převod; vybraná **modře**, nikdy černě.

**Pravý sloupec (5fr)** — `SHRNUTÍ / TV-2604` + počet položek. Kompaktní výrobní list: každá položka má index, soubor, konfiguraci, cenu a sekundární `UPRAVIT`. Seznam roste do `max-height: 340px`, pak scrolluje. Pod ním tisk, množstevní sleva, doprava. `ZÁVAZNÁ CENA` dominantní. CTA `Zaplatit 2 636 Kč`.

Pod CTA: *Tiskneme až po zaplacení. Před odesláním ti pošleme fotku dílu k odsouhlasení; když nebude sedět, tiskneme znovu nebo vracíme peníze.*

## Pravidla
Doprava se uvádí vždy samostatně. Součty musí být totožné s konfigurátorem, přijetím i sledováním. Úprava položky je možná, ale vizuálně sekundární. Žádný e-shopový košík.
