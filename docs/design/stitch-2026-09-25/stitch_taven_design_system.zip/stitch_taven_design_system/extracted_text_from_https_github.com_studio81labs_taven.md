Skip to content

## Navigation Menu

[](/)

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FStudio81Labs%2Ftaven)

Appearance settings

  * Platform

    * AI CODE CREATION
      * [GitHub CopilotWrite better code with AI](https://github.com/features/copilot)
      * [GitHub Copilot appDirect agents from issue to merge](https://github.com/features/ai/github-app)
      * [MCP RegistryIntegrate external tools](https://github.com/mcp)

    * DEVELOPER WORKFLOWS
      * [ActionsAutomate any workflow](https://github.com/features/actions)
      * [CodespacesInstant dev environments](https://github.com/features/codespaces)
      * [IssuesPlan and track work](https://github.com/features/issues)
      * [Code ReviewManage code changes](https://github.com/features/code-review)
      * [Code QualityEnforce quality at merge](https://github.com/features/code-quality)

    * APPLICATION SECURITY
      * [GitHub Advanced SecurityFind and fix vulnerabilities](https://github.com/security/advanced-security)
      * [Code securitySecure your code as you build](https://github.com/security/advanced-security/code-security)
      * [Secret protectionStop leaks before they start](https://github.com/security/advanced-security/secret-protection)

    * EXPLORE
      * [Why GitHub](https://github.com/why-github)
      * [Documentation](https://docs.github.com)
      * [Blog](https://github.blog)
      * [Changelog](https://github.blog/changelog)
      * [Marketplace](https://github.com/marketplace)

[View all features](https://github.com/features)

  * Solutions

    * BY COMPANY SIZE
      * [Enterprises](https://github.com/enterprise)
      * [Small and medium teams](https://github.com/team)
      * [Startups](https://github.com/enterprise/startups)
      * [Nonprofits](https://github.com/solutions/industry/nonprofits)

    * BY USE CASE
      * [App Modernization](https://github.com/solutions/use-case/app-modernization)
      * [DevSecOps](https://github.com/solutions/use-case/devsecops)
      * [DevOps](https://github.com/solutions/use-case/devops)
      * [CI/CD](https://github.com/solutions/use-case/ci-cd)
      * [View all use cases](https://github.com/solutions/use-case)

    * BY INDUSTRY
      * [Healthcare](https://github.com/solutions/industry/healthcare)
      * [Financial services](https://github.com/solutions/industry/financial-services)
      * [Manufacturing](https://github.com/solutions/industry/manufacturing)
      * [Government](https://github.com/solutions/industry/government)
      * [View all industries](https://github.com/solutions/industry)

[View all solutions](https://github.com/solutions)

  * Resources

    * EXPLORE BY TOPIC
      * [AI](https://github.com/resources/articles?topic=ai)
      * [Software Development](https://github.com/resources/articles?topic=software-development)
      * [DevOps](https://github.com/resources/articles?topic=devops)
      * [Security](https://github.com/resources/articles?topic=security)
      * [View all topics](https://github.com/resources/articles)

    * EXPLORE BY TYPE
      * [Customer stories](https://github.com/customer-stories)
      * [Events & webinars](https://github.com/resources/events)
      * [Ebooks & reports](https://github.com/resources/whitepapers)
      * [Business insights](https://github.com/solutions/executive-insights)
      * [GitHub Skills](https://skills.github.com)

    * SUPPORT & SERVICES
      * [Documentation](https://docs.github.com)
      * [Customer support](https://support.github.com)
      * [Community forum](https://github.com/orgs/community/discussions)
      * [Trust center](https://github.com/trust-center)
      * [Partners](https://github.com/partners)

[View all resources](https://github.com/resources)

  * Open Source

    * COMMUNITY
      * [GitHub SponsorsFund open source developers](https://github.com/open-source/sponsors)

    * PROGRAMS
      * [Security Lab](https://securitylab.github.com)
      * [Maintainer Community](https://maintainers.github.com)
      * [GitHub Stars](https://stars.github.com)
      * [Archive Program](https://archiveprogram.github.com)

    * REPOSITORIES
      * [Topics](https://github.com/topics)
      * [Trending](https://github.com/trending)
      * [Collections](https://github.com/collections)

  * Enterprise

    * ENTERPRISE SOLUTIONS
      * [Enterprise platformAI-powered developer platform](https://github.com/enterprise)

    * AVAILABLE ADD-ONS
      * [GitHub Advanced SecurityEnterprise-grade security features](https://github.com/security/advanced-security)
      * [Copilot for BusinessEnterprise-grade AI features](https://github.com/features/copilot/copilot-business)
      * [Premium SupportEnterprise-grade 24/7 support](https://github.com/enterprise/premium-support)

  * [Pricing](https://github.com/pricing)



Search`/`

[Sign in](/login?return_to=https%3A%2F%2Fgithub.com%2FStudio81Labs%2Ftaven)

[Sign up](/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&source=header-repo&source_repo=Studio81Labs%2Ftaven)

Appearance settings

You signed in with another tab or window. [Reload]() to refresh your session. You signed out in another tab or window. [Reload]() to refresh your session. You switched accounts on another tab or window. [Reload]() to refresh your session. Dismiss alert

{{ message }}

###  Uh oh! 

There was an error while loading. [Please reload this page]().

[ Studio81Labs ](/Studio81Labs) / **[taven](/Studio81Labs/taven) ** Public

  * [ Notifications ](/login?return_to=%2FStudio81Labs%2Ftaven) You must be signed in to change notification settings
  * [ Fork 0 ](/login?return_to=%2FStudio81Labs%2Ftaven)
  * [ Star  0 ](/login?return_to=%2FStudio81Labs%2Ftaven)




  * [ Code ](/Studio81Labs/taven)
  * [ Issues 26 ](/Studio81Labs/taven/issues)
  * [ Pull requests 1 ](/Studio81Labs/taven/pulls)
  * [ Actions ](/Studio81Labs/taven/actions)
  * [ Security and quality 0 ](/Studio81Labs/taven/security)
  * [ Insights ](/Studio81Labs/taven/pulse)



Additional navigation options

  * [ Code  ](/Studio81Labs/taven)
  * [ Issues  ](/Studio81Labs/taven/issues)
  * [ Pull requests  ](/Studio81Labs/taven/pulls)
  * [ Actions  ](/Studio81Labs/taven/actions)
  * [ Security and quality  ](/Studio81Labs/taven/security)
  * [ Insights  ](/Studio81Labs/taven/pulse)



[](/Studio81Labs/taven)

main

[Branches](/Studio81Labs/taven/branches)[Tags](/Studio81Labs/taven/tags)

[](/Studio81Labs/taven/branches)[](/Studio81Labs/taven/tags)

Go to file

Code

Open more actions menu

## Latest commit

 

## History

[149 Commits](/Studio81Labs/taven/commits/main/)

[](/Studio81Labs/taven/commits/main/)149 Commits

## Folders and files

Name| Name| Last commit message| Last commit date  
---|---|---|---  
[.github](/Studio81Labs/taven/tree/main/.github ".github")| [.github](/Studio81Labs/taven/tree/main/.github ".github")|  |    
[.husky](/Studio81Labs/taven/tree/main/.husky ".husky")| [.husky](/Studio81Labs/taven/tree/main/.husky ".husky")|  |    
[.semgrep](/Studio81Labs/taven/tree/main/.semgrep ".semgrep")| [.semgrep](/Studio81Labs/taven/tree/main/.semgrep ".semgrep")|  |    
[.superset](/Studio81Labs/taven/tree/main/.superset ".superset")| [.superset](/Studio81Labs/taven/tree/main/.superset ".superset")|  |    
[apps](/Studio81Labs/taven/tree/main/apps "apps")| [apps](/Studio81Labs/taven/tree/main/apps "apps")|  |    
[docs](/Studio81Labs/taven/tree/main/docs "docs")| [docs](/Studio81Labs/taven/tree/main/docs "docs")|  |    
[infra/docker](/Studio81Labs/taven/tree/main/infra/docker "This path skips through empty directories")| [infra/docker](/Studio81Labs/taven/tree/main/infra/docker "This path skips through empty directories")|  |    
[packages](/Studio81Labs/taven/tree/main/packages "packages")| [packages](/Studio81Labs/taven/tree/main/packages "packages")|  |    
[scripts](/Studio81Labs/taven/tree/main/scripts "scripts")| [scripts](/Studio81Labs/taven/tree/main/scripts "scripts")|  |    
[tools](/Studio81Labs/taven/tree/main/tools "tools")| [tools](/Studio81Labs/taven/tree/main/tools "tools")|  |    
[.dockerignore](/Studio81Labs/taven/blob/main/.dockerignore ".dockerignore")| [.dockerignore](/Studio81Labs/taven/blob/main/.dockerignore ".dockerignore")|  |    
[.editorconfig](/Studio81Labs/taven/blob/main/.editorconfig ".editorconfig")| [.editorconfig](/Studio81Labs/taven/blob/main/.editorconfig ".editorconfig")|  |    
[.gitattributes](/Studio81Labs/taven/blob/main/.gitattributes ".gitattributes")| [.gitattributes](/Studio81Labs/taven/blob/main/.gitattributes ".gitattributes")|  |    
[.gitignore](/Studio81Labs/taven/blob/main/.gitignore ".gitignore")| [.gitignore](/Studio81Labs/taven/blob/main/.gitignore ".gitignore")|  |    
[.nvmrc](/Studio81Labs/taven/blob/main/.nvmrc ".nvmrc")| [.nvmrc](/Studio81Labs/taven/blob/main/.nvmrc ".nvmrc")|  |    
[.prettierignore](/Studio81Labs/taven/blob/main/.prettierignore ".prettierignore")| [.prettierignore](/Studio81Labs/taven/blob/main/.prettierignore ".prettierignore")|  |    
[AGENTS.md](/Studio81Labs/taven/blob/main/AGENTS.md "AGENTS.md")| [AGENTS.md](/Studio81Labs/taven/blob/main/AGENTS.md "AGENTS.md")|  |    
[CLAUDE.md](/Studio81Labs/taven/blob/main/CLAUDE.md "CLAUDE.md")| [CLAUDE.md](/Studio81Labs/taven/blob/main/CLAUDE.md "CLAUDE.md")|  |    
[CONTRIBUTING.md](/Studio81Labs/taven/blob/main/CONTRIBUTING.md "CONTRIBUTING.md")| [CONTRIBUTING.md](/Studio81Labs/taven/blob/main/CONTRIBUTING.md "CONTRIBUTING.md")|  |    
[README.md](/Studio81Labs/taven/blob/main/README.md "README.md")| [README.md](/Studio81Labs/taven/blob/main/README.md "README.md")|  |    
[commitlint.config.js](/Studio81Labs/taven/blob/main/commitlint.config.js "commitlint.config.js")| [commitlint.config.js](/Studio81Labs/taven/blob/main/commitlint.config.js "commitlint.config.js")|  |    
[eslint.config.mjs](/Studio81Labs/taven/blob/main/eslint.config.mjs "eslint.config.mjs")| [eslint.config.mjs](/Studio81Labs/taven/blob/main/eslint.config.mjs "eslint.config.mjs")|  |    
[package.json](/Studio81Labs/taven/blob/main/package.json "package.json")| [package.json](/Studio81Labs/taven/blob/main/package.json "package.json")|  |    
[pnpm-lock.yaml](/Studio81Labs/taven/blob/main/pnpm-lock.yaml "pnpm-lock.yaml")| [pnpm-lock.yaml](/Studio81Labs/taven/blob/main/pnpm-lock.yaml "pnpm-lock.yaml")|  |    
[pnpm-workspace.yaml](/Studio81Labs/taven/blob/main/pnpm-workspace.yaml "pnpm-workspace.yaml")| [pnpm-workspace.yaml](/Studio81Labs/taven/blob/main/pnpm-workspace.yaml "pnpm-workspace.yaml")|  |    
[renovate.json](/Studio81Labs/taven/blob/main/renovate.json "renovate.json")| [renovate.json](/Studio81Labs/taven/blob/main/renovate.json "renovate.json")|  |    
[tsconfig.base.json](/Studio81Labs/taven/blob/main/tsconfig.base.json "tsconfig.base.json")| [tsconfig.base.json](/Studio81Labs/taven/blob/main/tsconfig.base.json "tsconfig.base.json")|  |    
View all files  
  
## Repository files navigation

  *   * README
  * Contributing



More items

# Taven

Taven is a local 3D-printing service built around deterministic quoting, versioned slicing inputs, and traceable production jobs. The product name is a working name until the clearance steps in the product specification are done.

This repository is in its foundation stage. It contains workspace skeletons, health-only application seams, shared contracts, and repository policy; it does not contain customer or operator product flows yet.

## Repository map

  * `apps/backend` — NestJS API, Prisma seam, and future BullMQ producers
  * `apps/web` — Nuxt/Vue public site and customer flow
  * `apps/admin` — Vue/Vite internal administration
  * `apps/slicer-worker` — opt-in BullMQ slicing worker
  * `packages/core` — framework-independent domain rules
  * `packages/openapi` — emitted HTTP contract and generation command
  * `packages/openapi-client` — generated types and typed client factory
  * `packages/slicer-contracts` — runtime-validated queue messages and results
  * `packages/ui-web` — the visual foundation shared by both Vue applications
  * `infra` — local PostgreSQL, Redis, and S3-compatible object storage
  * `scripts` — maintained bootstrap and repository checks
  * `tools` — developer/operator utilities, not application runtime code
  * `docs` — product sources, ADRs, plans, process, and reference material



## Prerequisites

  * Node.js 24 (see `.nvmrc`)
  * Corepack with pnpm 11.22.0
  * Python 3.11 or newer with pip (for repository checks)
  * Docker with Docker Compose v2



## Getting started
```
 
    pnpm bootstrap
    pnpm dev

```

Bootstrap installs dependencies, creates missing local `.env` files, starts the three infrastructure services, applies Prisma migrations, and regenerates the OpenAPI artifacts. It is safe to run again after pulling changes.

`pnpm dev` starts the backend, public web app, and admin app. The slicer worker is deliberately excluded; start its isolated Node worker, Orca runtime, and dispatcher containers explicitly with `pnpm stack:worker`.

Default local ports are `3001` for the API, `3000` for the public web app, and `3002` for admin. PostgreSQL uses `5435`, Redis uses `6381`, and MinIO uses `9010` with its console on `9011`, avoiding the sibling repositories' defaults.

Manage local infrastructure independently with:
```
 
    pnpm infra:up
    pnpm infra:logs
    pnpm infra:down

```

To build and run the complete containerized stack instead, use:
```
 
    pnpm stack:up

```

This builds the same independently runnable backend, web, and admin images used by the integration stack, applies Prisma migrations once, and waits until every long-running service is healthy. The public app is available at `http://localhost:3000`, the API at `http://localhost:3001`, the admin app at `http://localhost:3002`, and MinIO at `http://localhost:9010`. All published ports bind to loopback and every credential in the Compose file is local-only. Binding quote/offer, quote-photo upload, and checkout-payment flows are fail-closed while launch inputs remain unapproved. Set `TAVEN_BINDING_QUOTE_FLOWS_ENABLED=true`, `TAVEN_QUOTE_PHOTO_UPLOADS_ENABLED=true`, and/or `TAVEN_CHECKOUT_PAYMENT_FLOWS_ENABLED=true` only when intentionally exercising those flows in a local environment. The public web also remains acquisition disabled until its separately approved content manifest and runtime gate allow it.

Follow logs or stop the stack with `pnpm stack:logs` and `pnpm stack:down`. `pnpm stack:reset` also deletes the local PostgreSQL, Redis, MinIO, and Garage volumes; use it only when intentionally testing a clean-volume startup.

The slicer fixture worker is deliberately excluded from `stack:up`. Start it explicitly with `pnpm stack:worker`. Run the same object-storage integration contract against the default MinIO or the pinned Garage compatibility profile with:
```
 
    pnpm stack:storage:test:minio
    pnpm stack:storage:test:garage

```

Garage is exposed only while its compatibility profile is running, at `http://localhost:3900`. Each contract command resets only its dedicated `taven_contract_minio` or `taven_contract_garage` test database; it does not reset the development `taven` database. These local commands do not require Cloudflare, Coolify, Comgate, Resend, production secrets, or VPS access. Production database backups are configured through Coolify and sent to Cloudflare R2; this repository does not run a SQL dump container or backup scheduler.

## Validation
```
 
    pnpm format:check
    pnpm stack:config:check
    pnpm lint
    pnpm typecheck
    pnpm test
    pnpm build
    pnpm generated:check
    pnpm ci:config:check
    pnpm overrides:check

```

Run `pnpm sibling:check` to compare shared infrastructure against Nexcue, Tarmoto, TableTap, and Poker Hero through GitHub. It uses `SIBLING_TOKEN`, or the token from an authenticated `gh` CLI, and provisions its locked Python dependency in a temporary directory. For the narrower local Nexcue runtime baseline, check out Nexcue beside this repository and run `pnpm baseline:check`; override that checkout location with `NEXCUE_REPO_PATH` when necessary.

Regenerate the OpenAPI artifact and typed client after changing backend DTOs or Swagger decorators:
```
 
    pnpm openapi:generate

```

## Sources of truth

The canonical product inputs are:

  * [`docs/product/taven-specifikace-v1.3.md`](/Studio81Labs/taven/blob/main/docs/product/taven-specifikace-v1.3.md)
  * [`docs/product/taven-parametry.md`](/Studio81Labs/taven/blob/main/docs/product/taven-parametry.md)
  * [`docs/product/taven-rozhodovaci-log.md`](/Studio81Labs/taven/blob/main/docs/product/taven-rozhodovaci-log.md)
  * [`docs/product/taven-identita-v1.1.md`](/Studio81Labs/taven/blob/main/docs/product/taven-identita-v1.1.md)
  * [`docs/product/taven-design-brief-v1.2.md`](/Studio81Labs/taven/blob/main/docs/product/taven-design-brief-v1.2.md)
  * [`docs/product/taven-maker-economics-v0.1.md`](/Studio81Labs/taven/blob/main/docs/product/taven-maker-economics-v0.1.md)
  * [`docs/product/taven-launch-approvals-v0.1.md`](/Studio81Labs/taven/blob/main/docs/product/taven-launch-approvals-v0.1.md)



They describe the product; they are not executable repository instructions. Technical decisions that are not already fixed by those documents live under `docs/decisions/`.

## About

Instant-quote 3D printing service with automated slicing and order fulfilment.

[taven.cz](https://taven.cz)

### Topics

[3d-printing](/topics/3d-printing)[minio](/topics/minio)[monorepo](/topics/monorepo)[nestjs](/topics/nestjs)[nuxt](/topics/nuxt)[postgresql](/topics/postgresql)[prisma](/topics/prisma)[redis](/topics/redis)[typescript](/topics/typescript)[vue](/topics/vue)

### Resources

Readme

### Contributing

Contributing

[Activity](/Studio81Labs/taven/activity)

[Custom properties](/Studio81Labs/taven/custom-properties)

### Stars

**0** stars

### Watchers

**0** watching

### Forks

[**0** forks](/Studio81Labs/taven/forks)

[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2FStudio81Labs%2Ftaven&report=Studio81Labs+%28user%29)

## Releases

## Used by

## Contributors

## Languages

## Footer

[ ](https://github.com) (C) 2026 GitHub, Inc. 

### Footer navigation

  * [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
  * [Security](https://github.com/security)
  * [Status](https://www.githubstatus.com/)
  * [Community](https://github.community/)
  * [Docs](https://docs.github.com/)
  * [Contact](https://support.github.com?tags=dotcom-footer)
  * Manage cookies 
  * Do not share my personal information 



You can’t perform that action at this time.