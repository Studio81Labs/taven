# 05 — Detail ukázky

`screen: 'ukazka'` · `LIST 03A / 05` · veřejná šablona

## Účel
Jeden záznam jako list výkresu: fotky, metadata, krátký popis zakázky.

## Struktura
Zpětný odkaz `‹ UKÁZKY / D-0142`.

**Levý sloupec (7fr)** — hlavní foto 16:10 s `FOTO — CELEK` a `D-0142 / REV. 01`, pod ním tři menší: `DETAIL A`, `DETAIL B`, `MĚŘENÍ`.

**Pravý sloupec (4fr)** — `ZÁZNAM D-0142` + **Kryt čerpadla** + odstavec o zakázce (náhrada popraskaného originálu, STL od zákazníka, doplněné sražení hran, tři kusy na podložku). Pod tím tabulka metadat:

`ČÍSLO · MATERIÁL · BARVA · KVALITA · MNOŽSTVÍ · ČAS TISKU · CENA TISKU · REVIZE`

Uzavírá sekundární tlačítko `Nahrát podobný model`.

## Pravidla
Cena a čas tisku se uvádějí, protože podporují hlavní sdělení o průhlednosti. Popis zakázky zůstává lidský — co to je a proč to vzniklo, ne výpis parametrů.
