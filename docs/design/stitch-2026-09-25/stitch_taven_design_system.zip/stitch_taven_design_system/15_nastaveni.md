# 15 — Nastavení

`screen: 'nastaveni'` · účtová šablona

## Účel
Jen to nutné. Účet je archiv, ne profil.

## Struktura
Záhlaví `ÚČET / ZÁKLADNÍ ÚDAJE` + **Nastavení**, vpravo `‹ MOJE ZAKÁZKY`.

**Levý sloupec (7fr)** — dokument s poli `E-MAIL`, `JMÉNO`, `TELEFON — NEPOVINNÉ`; `Uložit` (primární) + `ODHLÁSIT` jako mono odkaz.

**Pravý sloupec (4fr)** — `ZRUŠENÍ ÚČTU` nad linkou `--stop`: *Smazáním účtu zmizí archiv zakázek. Doklady, které musíme podle zákona uchovat, zůstávají mimo účet.* + odkaz `SMAZAT ÚČET` v `--stop`.

## Nepoužívat
Avatar, předvolby, notifikace, věrnostní systém, cokoli, co z archivu dělá profil.
