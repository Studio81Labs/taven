# 21 — Tokeny a komponenty

`screen: 'tokeny'` · kompletní systémový přehled stavebních prvků

## Účel
Kompletní katalog komponent a barevných i typografických tokenů pro implementaci rozhraní.

## Barevné tokeny
- `--paper`: `#EFEFEA` (podklad stránek a aplikačního plátna)
- `--surface`: `#FFFFFF` (bílé karty, modelové plátno, funkční formuláře)
- `--surface-2`: `#F7F7F4` (pravý kontextový panel konfigurátoru)
- `--field`: `#FCFCFB` (vstupní pole)
- `--ink`: `#1A1A16` (hlavní text, rámy, silné linky)
- `--ink-2`: `#54554C` (sekundární popisky a odstavce)
- `--ink-3`: `#83847A` (metadata, kóty, nejnižší kontrastní stupeň)
- `--rule`: `#D9D9D2` (vnitřní dělicí linky 1px)
- `--rule-2`: `#C9C9C1` (silnější linky a vnější ohraničení mřížky)
- `--accent`: `#1B44E8` (závazná cena, aktivní krok, vybrané stavy, primární CTA)
- `--accent-hover`: `#0F2FA8` (hover stav primárních prvků)
- `--warn`: `#B4741A` (upozornění, dotaz na jednotky/měřítko)
- `--stop`: `#B4441A` (chyba geometrie, odmítnutí modelu, smazání)

## Typografický systém
- **IBM Plex Sans**:
  - Hero: 36–38px / 600 / -0.02em
  - Obrazovkový nadpis: 26–32px / 600 / -0.02em
  - Sekční nadpis: 20px / 600 / -0.01em
  - Body text: 14–15px / 400 / line-height 1.6
- **IBM Plex Mono**:
  - Čísla a ceny: 26–40px / 600 / -0.02em
  - Kóty a štítky: 10.5–12.5px / 500 / uppercase
  - Popisky polí: 10px / 600 / 0.12em uppercase

## Přehled klíčových komponent
1. `BrandHeader` & `ProcessHeader`
2. `ModelDrawingFrame` (kóty, osy XYZ, rastr 16/80px)
3. `BindingPrice` (mikroanimace přepočtu z orientační na závaznou)
4. `PreflightFinding` (kontrola geometrie před tiskem)
5. `QCPhotoCard` (fotka z výroby před expedicí ke schválení)
6. `ProductionTimeline` (reálné stavy výroby bez interních stavových kódů)
7. `TitleBlockFooter` & `CompactTitleBlockFooter` (technické rohové razítko)
