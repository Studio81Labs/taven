# 10 — Přijato

`screen: 'confirm'` · aplikační šablona · `05 VÝROBA` aktivní

## Účel
Po zaplacení zákazník vstupuje do **výroby**, ne na generickou „hotovo“ obrazovku. Tady je také jediné místo, kde nabízíme účet.

## Struktura
**Levý sloupec (7fr)** — `PLATBA PŘIJATA 13:41` + **Zakázka TV-2604 je přijata** + *Potvrzení jsme poslali na adam@example.cz. Odkaz na sledování zakázky a na odsouhlasení fotky dostaneš e-mailem — účet k tomu nepotřebuješ.* Sekundární `Sledovat zakázku →`.

Pod tím dokument `NEPOVINNÉ`: **Chceš mít všechny zakázky na jednom místě?** + vysvětlení + `Vytvořit účet` (primární) a věta *Můžeš pokračovat i bez účtu.*

**Pravý sloupec (5fr)** — `VÝROBNÍ LIST / TV-2604`: položky, doprava s výdejním místem, `Zaplaceno` s celkovou částkou.

## Pravidla
Účet je pohodlí, ne podmínka. Nikde nesmí vzniknout dojem, že bez účtu zakázku neuvidíš.
