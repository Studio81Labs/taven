# 08 — Konfigurátor

`screen: 'config'` · aplikační šablona · nejdůležitější obrazovka

## Hlavička
`ProcessHeader`: `TAVEN.` + `01 SOUBOR — 02 KONFIGURACE — 03 DOPRAVA — 04 PLATBA — 05 VÝROBA`, aktivní krok modrý, hotové neutrální, budoucí potlačené. Vpravo `OrderIndicator` `OBJ. / 03 / 2 636 Kč` — sekundární ke kroku, otevírá checkout.

## Geometrie
Dva sloupce `7fr / 5fr`, dělicí linka fixní. Levý `--paper`, pravý `--surface-2` po celou pracovní výšku. **Barva ani šířka se mezi stavy nemění.**

## Stavy

| Stav | Levý sloupec | Pravý panel |
| --- | --- | --- |
| `empty` | dropzone 420px | `STAV SOUBORU` — vše čeká; *Zatím není co počítat.* |
| `slicing` | plátno modelu + progres `Počítám přesnou cenu` | pipeline běží (modré `PROBÍHÁ`) + parametry + orientační cena šedě |
| `ready` | plátno modelu + nálezy před tiskem | parametry + `ZÁVAZNÁ CENA` modře, rozpad, expres, CTA |
| `added` | plátno modelu | `OBJEDNÁVKA / TV-2604` — položky, nejnovější zvýrazněná, součet, dvě akce |
| `mesh` | odmítnutí s konkrétním důvodem (`--stop`) | pipeline `NELZE` + *Cenu nespočítáme, dokud nebude geometrie uzavřená.* |
| `units` | dotaz na jednotky (`--warn`) | pipeline `DOTAZ` + vysvětlení, proč cena čeká |
| `assembly` | výběr těles s cenami | průběžný součet vybraných + orientační poznámka |

## Panel se posouvá významem
`STAV SOUBORU` → `KONFIGURACE / CENA` → `OBJEDNÁVKA`. Nikdy prázdná bílá karta, nikdy druhá karta uvnitř panelu.

## Plátno modelu
Rám `1px --ink`, rastr 16/80px, kóty s koncovkami (modře), osy `X/Z`, vlevo nahoře jméno souboru, vpravo `TĚLESO 01 / 01`, počet trojúhelníků, pohled; vlevo dole rozměry a objem.

## Parametry — přesně čtyři
`MATERIÁL` (PLA / PETG, u každého výsledná cena tisku) · `BARVA` (jen skladem, vybraná má modrý outline) · `KVALITA` (tři pojmenované stupně s přepočtenou cenou, u minima poznámka `min. cena tisku`) · `POČET KUSŮ` (1 / 5 / 20 s cenou za kus + volné pole).

Pod materiálem: *Volby ukazují výslednou cenu tisku téhle konfigurace.*

**Zakázáno:** slider výplně, výběr trysky, teploty, styl podpěr, orientace.

## Nálezy před tiskem
Max tři, nezaškrtnuté, zákazník potvrzuje aktivně. Lidskou řečí, vizuálně klidné. Bez potvrzení všech je CTA neaktivní s vysvětlením.

## Cena
Popisek `ORIENTAČNÍ CENA` (šedě) → `ZÁVAZNÁ CENA` (modře) s mikroanimací — to je celý produkt v jednom přechodu. Pod ní rozpad: tisk, malá zakázka, sleva, doprava, expres. CTA: `Přidat do objednávky — 379 Kč`.

## Expres
`Expresní výroba / dokončení do 24 hodin, ne rychlejší doprava`, `+ 2× cena tisku`. Nezobrazí se, pokud není dostupný (jemná kvalita, 20+ ks). Nikdy nevypadá jako doporučená volba.
