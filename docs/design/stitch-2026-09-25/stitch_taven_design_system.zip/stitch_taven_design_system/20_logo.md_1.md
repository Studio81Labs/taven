# 20 — Logo

`screen: 'brand'` · systémový list

## Primární značka
**`TAVEN.`** — mono, 600, modrá tečka.

Tečka znamená: hotovo · definitivní · závazné · není co vyjednávat. Je to jediné místo, kde se modrá objevuje bez funkčního důvodu.

## Tři směry
| Č. | Směr | Popis |
| --- | --- | --- |
| 01 | KÓTA | značka jako kótovaný rozměr; kóta se dá použít samostatně jako oddělovač v rozhraní |
| 02 | TEČKA | **primární** — tečka jako konec věty |
| 03 | VRSTVA | písmo prořezané vrstvami tisku; nejvýraznější, ale hůř čitelné v malých velikostech |

Rozhodnutí: primární je **02 TEČKA**. Směr 01 přežívá jako grafický motiv (kótové předěly). Směr 03 se primární značkou nestává.

## Varianty
Na `--ink` podkladu (tečka `#5C7CFF` pro kontrast) · malá velikost 13px · monogram `TV.`

## Pravidla
Jednobarevná varianta zůstává otevřená. Modrá tečka je nepřenositelná — nikdy ji nepoužívat jako dekorativní prvek jinde.
