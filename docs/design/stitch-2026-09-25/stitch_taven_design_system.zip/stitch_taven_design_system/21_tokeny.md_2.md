# 21 — Tokeny a komponenty

`screen: 'tokens'` · systémový list

## Účel
Zabránit tomu, aby implementace znovu vymýšlela obrazovky ad hoc. Úplné hodnoty jsou v [../DESIGN.md](../DESIGN.md).

## Obsah listu
1. **Swatche** — devět tokenů s hodnotou a použitím.
2. **Typografie** — hero, nadpis sekce, text, číslo, popisek pole; u každého název tokenu a sazba.
3. **Proměnné** — blok na `--ink` podkladu s barvami, fonty a mřížkou (`--grid-minor: 16px`, `--grid-major: 80px`, `--rule-w: 1px`, `--rule-strong: 2px`).
4. **Kótový předěl** `DETAIL A / PRVKY SYSTÉMU` → ukázky navigace, procesní hlavičky, kótového oddělovače a popiskové linky.
5. **Rozpis / title block** — zkrácená ukázka patičky.
6. **Poměr plochy** — pruh 80 / 15 / 5 s popisky.
7. **Kótový předěl** `SEKCE 04 / KOMPONENTY` → živé ukázky `PreflightFinding` (výchozí / potvrzeno), `BindingPrice` (orientační / závazná), `ProductionTimeline` (hotovo / čeká), `PartCard + TechnicalMetadata`.
8. **Tabulka komponent** — `KOMPONENTA / POUŽITÍ / SAZBA A LINKY / MODRÁ` pro všech 19 komponent.

## Pravidla
Každá komponenta má demonstrovaný výchozí i aktivní stav, uvedenou sazbu, tloušťku linek a **povolené použití modré**. Sloupec MODRÁ je normativní: `—` znamená, že komponenta modrou nepoužívá vůbec.
