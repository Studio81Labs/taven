# Taven — designový systém
3D tisk na zakázku. Zákazník nahraje model, dostane **závaznou cenu**, zaplatí, Taven vyrobí.
Claim: **Nahraj. Zaplať. Hotovo.**
Hero: **ZÁVAZNÁ CENA DO DVOU MINUT / Nahraj model. Cena platí.**
Vizuální metafora: *technický výkres převedený do spotřebitelské služby.* Ne CAD, ne SaaS dashboard, ne e-shop.
Soubory:
- `Taven.dc.html` — kompletní klikací prototyp, všech 21 obrazovek (aktivní)
- `Taven Stránky.dc.html` — původní samostatný list veřejných/právních/účtových stránek, dnes redundantní
Jazyk: **čeština všude**, včetně mikrotextů a stavů. Tykání.
---
## 1. Tokeny
| Token | Hodnota | Použití |
| --- | --- | --- |
| `--paper` | `#EFEFEA` | podklad stránky, levý sloupec aplikace |
| `--surface` | `#FFFFFF` | plátno modelu, karty, funkční dokumenty |
| `--surface-2` | `#F7F7F4` | pravý kontextový panel aplikace |
| `--field` | `#FCFCFB` | vstupní pole |
| `--ink` | `#1A1A16` | text, kóty, silné linky |
| `--ink-2` | `#54554C` | sekundární text |
| `--ink-3` | `#83847A` | mikrotexty, metadata (nejnižší povolená úroveň) |
| `--rule` | `#D9D9D2` | linky 1px |
| `--rule-2` | `#C9C9C1` | silnější oddělení, mřížka rozpisu |
| `--accent` | `#1B44E8` | závazná cena, aktivní krok, vybráno, primární CTA |
| `--accent-hover` | `#0F2FA8` | hover primárního tlačítka |
| `--warn` | `#B4741A` | dotaz na měřítko, výběr těles |
| `--stop` | `#B4441A` | odmítnutí souboru, smazání účtu |
Mřížka výkresu: minor `16px` `#F1F1EC`, major `80px` `#E4E4DE`. Linky `1px`, silné `2px`. **Nulový border-radius.**
### Poměr plochy
`80 %` typografie a prázdné místo · `15 %` linky, rastr a metadata · `5 %` akcent.
---
## 2. Typografie
`IBM Plex Sans` (text) + `IBM Plex Mono` (**každé číslo, každý popisek, každé metadatum**).
| Role | Sazba |
| --- | --- |
| hero | Sans 600 / 36–38px / −0.02em |
| nadpis obrazovky | Sans 600 / 26–32px / −0.02em |
| nadpis sekce | Sans 600 / 20px / −0.01em |
| text | Sans 400 / 14–15px / line-height 1.55–1.65 |
| právní text | Sans 400 / 15px / 1.65 / max-width 660px |
| číslo, cena | Mono 600 / 26–40px / −0.02em |
| popisek pole | Mono 10px / 0.12em / uppercase |
| metadatum | Mono 10.5–12.5px / 0.06–0.1em |
Minimální text v rozhraní 12px, právní text nikdy pod 15px.
---
## 3. Barva jako význam
**Modrá = primární akce nebo vybráno. Černá ani jedno.**
Akcent identifikuje: tečku v logu · závaznou cenu · aktivní krok procesu · vybraný materiál, barvu, kvalitu, počet, výdejní místo · primární CTA · důležitou kótu nebo anotaci.
Vybraný stav: `border: 1px solid --accent` + `box-shadow: inset 2px 0 0 --accent` + bílý podklad — tedy **tvar i barva**, ne jen barva. Sekundární tlačítko: `1px solid --ink`, bez výplně. `--warn` a `--stop` jen pro skutečně odlišnou závažnost.
---
## 4. Komponenty
| Komponenta | Použití | Modrá |
| --- | --- | --- |
| `BrandHeader` | identita + claim + lokalita | jen tečka |
| `HomepageNavigation` | indexované položky 01–04 + CTA `NAHRÁT MODEL`, vedle nenápadné `PŘIHLÁSIT` | podtržení aktivní položky |
| `ProcessHeader` | `01 SOUBOR — 02 KONFIGURACE — 03 DOPRAVA — 04 PLATBA — 05 VÝROBA`, spojky 18×1px | aktivní krok |
| `OrderIndicator` | `OBJ. / 03 / 2 636 Kč` v hlavičce, sekundární ke kroku | — |
| `SectionMarker` | `DETAIL A`, `ŘEZ B–B`, `REV. 01`, `LIST 02 / 05` | — |
| `DimensionSeparator` | předěl s kótou, **max. 2–3 na stránku** | — |
| `LeaderAnnotation` | odkazová linka ke skutečné informaci (bod 5px + linka) | linka i bod |
| `DrawingZone` | souřadnice A–E u okraje listu, podprahové | — |
| `DrawingGrid` | rastr pod plátnem modelu, nikdy pod textem | — |
| `ModelDrawingFrame` | model, kóty, osy XYZ, jméno souboru, počet těles, pohled, objem | kóty |
| `TechnicalMetadata` | dvojice popisek — hodnota | — |
| `BindingPrice` | orientační (šedá) → závazná (modrý popisek), rozpad položek | popisek |
| `PreflightFinding` | nález k aktivnímu potvrzení, klidný ne alarmující | potvrzeno |
| `PartCard` | záznam dílu `D-0142` — foto dominuje, metadata sekundární | — |
| `ProductionTimeline` | čas — stav — lidská věta | — |
| `QCPhotoCard` | fotka ke schválení, `POŘÍZENO 14:02` | primární tlačítko |
| `AccountOrderList` | registr zakázek, indexované záznamy + pruh fáze | živá zakázka |
| `TitleBlockFooter` | rozpis: 4 cely + spodní lišta, veřejné a právní stránky | jen tečka |
| `CompactTitleBlockFooter` | 3 cely, 70–100px, aplikační tok | jen tečka |
---
## 5. Pravidla
**Technická anotace musí nést informaci.** Kóta, vlastnost souboru, stav, sekce, vztah, výrobní omezení nebo vlastnost ceny. Nikdy dekorace.
**Stabilní geometrie aplikace.** Dva sloupce od nahrání po konfiguraci. Levý `--paper`, pravý `--surface-2` po celou pracovní výšku — barva a geometrie se nemění, mění se obsah. Panel se posouvá významem: `STAV SOUBORU` → `KONFIGURACE / CENA` → `OBJEDNÁVKA`. Žádná druhá bílá karta uvnitř panelu, žádný prázdný success card.
**Zakázané vzory.** Obří černý headline přes celou šířku · tři stejné karty vedle sebe · kroky 01–04 v řadě jako dekorace · vlasové 1px linky jako jediný oddělovač · early access, odpočet, waitlist · stock fotky tiskáren a rendery · tmavý režim jako výchozí · ikony ozubených kol, raket, blesků, trysek, hexagonů · gradienty, glassmorphism, zaoblené karty · košík a e-shopové badge · SaaS dashboard, avatary, notifikační centrum · rastr pod dlouhým právním textem.
---
## 6. Cenový model
Cena vzniká **ze slicingu**, ne z gramáže. Univerzální Kč/g se neinzeruje.
| Pravidlo | Hodnota |
| --- | --- |
| minimální cena tisku | 250 Kč (na položku) |
| malá zakázka | +50 Kč (do 100 g) |
| doprava — výdejní místo | 79 Kč |
| expresní výroba | 2× cena tisku, dokončení do 24 h |
| množstevní sleva | od 5 ks −8 %, od 20 ks −18 % |
| materiály | PLA / PETG, jen barvy na skladě |
| termín | do 3 pracovních dnů |
Referenční díl `kryt-cerpadla-v3.stl`, 42,8 g, PLA, standardní, 1 ks: tisk 250 + malá zakázka 50 + doprava 79 = **379 Kč**. Stejná čísla musí platit v konfigurátoru, checkoutu, shrnutí i sledování.
Volby ukazují **výslednou cenu tisku**, nikdy procentní koeficient — procenta by tvrdila, že cena vzniká násobkem, a to podkopává celé sdělení. Expres je priorita ve výrobě, ne rychlejší doprava.
---
## 7. Produktová pravidla
**Objednávka = jedna nebo více samostatně konfigurovaných položek.** Každá má svůj soubor, tělesa, materiál, barvu, kvalitu, počet a cenu. Sestava s víc tělesy neznamená víc položek. Po konfiguraci: `Pokračovat k dopravě` / `+ Přidat další model` — přidání vrací na krok `01 SOUBOR` a už přidané položky zůstávají.
**Účet je nepovinný.** Registrace není nikdy podmínkou nahrání, cenové nabídky, platby, sledování ani odsouhlasení fotky. Host dostává bezpečné odkazy e-mailem. Nabídka účtu přichází **až po zaplacení**. Účet je archiv zakázek, nic víc. Sledování zakázky je jeden a tentýž dokument pro přihlášené i hosty.
**Provozovatele nezveřejňujeme jmenovitě.** Taven provozuje Studio81 Labs. Žádná výrobní adresa, žádné jméno obsluhy, žádný stroj ve sledování zakázky. Právní identifikace **jen v rozpisu v patičce**. Ve mockupu placeholdery v hranatých závorkách: `[IČO]`, `[TELEFON]`, `[E-MAIL]`, `[PRÁVNÍ FORMA]`.
**Nálezy před tiskem** potvrzuje zákazník aktivně, max. tři, lidskou řečí. Neslibujeme deterministické rozměrové výsledky — Taven ručí za soulad s modelem, ne za mechanické pasování.
---
## 8. Obrazovky (21)
**Veřejné** — Landing · Jak to funguje (07 kroků) · Ceník (pravidla + 3 skutečné zakázky) · Ukázky (registr + filtr) · Detail ukázky · Potřebuji model (formulář, individuální nabídka) · Kontakt (3 cely dotazů)
**Tok** — Konfigurátor (stavy: prázdný, počítá, hotovo, přidáno, neopravitelný mesh, měřítko, sestava) · Checkout · Přijato · Sledování a odsouhlasení fotky
**Účet** — Přihlášení (magic link) · Aktivace · Moje zakázky (registr) · Nastavení
**Právní** — VOP (08 oddílů) · Reklamace (podpora + 4 situace) · Ochrana soukromí (tabulka retence, výrobní soubory 90 dní)
**Systém** — Responzivně (390 / 768 / 1440) · Logo (3 směry, primární `TAVEN.` s tečkou) · Tokeny a komponenty
---
## 9. Responzivně
`1440` desktop · `768` tablet (model nad ovládáním) · `390` mobil.
Na mobilu: zachovat `TAVEN.`, navigaci složit do `01–04 MENU`, kontext kroku jako `02 KONFIGURACE / 05`, závazná cena ve sticky liště u primární akce, rozpis patičky složit vědomě (ne vertikální stack všech cel), technickou identitu nést typografií, linkami a metadaty — ne rastrem. Cílové plochy min. `44px`, u tlačítek `48px`.
---
## 10. Kontrola před odevzdáním
- Je první akcí nahrání souboru? → **ano**
- Je všechen text česky? → **ano**
- Jsou všechna čísla v Plex Mono? → **ano**
- Je akcentní barva pod 5 % plochy? → **ano**
- Znamená modrá primární i vybrané a černá ani jedno? → **ano**
- Sedí součty na všech obrazovkách navzájem? → **ano**
- Je někde jméno, IČO, adresa, telefon nebo stroj? → **ne**, jen hranaté závorky
- Je někde volba mezi dodavateli? → **ne**
- Vyžaduje některá cesta účet? → **ne**
- Prošel návrh zakázanými vzory? → **žádná položka**