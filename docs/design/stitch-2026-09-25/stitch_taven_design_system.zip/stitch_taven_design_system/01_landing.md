# 01 — Landing

`screen: 'landing'` · `LIST 01` · veřejná šablona

## Účel
Do tří sekund musí být čitelné jediné sdělení: **nahraj model, cena platí**. První akcí je nahrání souboru, ne čtení.

## Struktura
1. **Hlavička** — `TAVEN.` + `NAHRAJ. ZAPLAŤ. HOTOVO.`, vpravo `3D TISK NA ZAKÁZKU / ČR`. Druhý řádek: indexovaná navigace `01 JAK TO FUNGUJE` … `04 POTŘEBUJI MODEL`, vpravo nenápadné `PŘIHLÁSIT` a rámované `NAHRÁT MODEL`.
2. **Hero** — `ZÁVAZNÁ CENA DO DVOU MINUT` / **Nahraj model. Cena platí.** / jedna věta o slicingu.
3. **Dropzone** (7fr) — přerušovaný rám, `Přetáhni soubor sem` / `vyber z disku`. Vpravo (4fr) odkazová linka na `STL · 3MF · STEP / max. 250 MB`, pod ní druhý vchod *Pošli fotku rozbitého dílu →* a technický výtah: odesíláme / expres / materiály.
4. **Kótový předěl** `01 / JAK TO FUNGUJE` → tři kroky na časové ose `00:00 / 00:40 / 02:00`.
5. **Kótový předěl** `ŘEZ A–A / JAK VZNIKÁ CENA` → srovnání *odhad podle gramáže* vs. *skutečný řez* na rastru.
6. **Ceník** — pravidla + poznámka o poměru za gram u větších dílů.
7. **Ukázky** — čtyři `PartCard` se záznamy `D-01xx`.
8. **Za zakázku ručí Taven** — čtyři číslované poznámky: závazná cena před nákupem · kontrola každého výtisku · fotka před odesláním · prodávajícím je Studio81 Labs.
9. **`TitleBlockFooter`** — rozpis se čtyřmi celami a spodní lištou `REV. 01 / © 2026 TAVEN / LIST 01 / 01`.

## Chování
- Dropzone i *vyber z disku* → `Konfigurátor` ve stavu `slicing` (progres od nuly).
- Navigace, `PŘIHLÁSIT` i odkazy v patičce vedou na reálné obrazovky.
- Drawing zones `A–E` u obou okrajů listu, podprahové.

## Nepoužívat
Druhý vchod jako rovnocenné tlačítko. Slider výplně nebo jakýkoli technický parametr na landingu. Obří claim s tlačítkem pod ním.
